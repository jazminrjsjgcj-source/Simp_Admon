<?php

namespace App\Services;

use App\Support\TextoNormalizador;

/**
 * Limpia la consulta de búsqueda del usuario antes de que las demás capas
 * (detector de intención, diccionario, FULLTEXT) la procesen.
 *
 * Responsabilidad única: convertir texto libre en las distintas formas que
 * cada capa necesita. No decide qué significan esas palabras (eso es
 * SearchIntentDetector) ni busca nada en ninguna tabla.
 *
 * Devuelve DOS versiones de la consulta, no una sola, porque cada capa
 * necesita algo distinto:
 *
 *   - 'consulta_normalizada': el texto completo con acentos y mayúsculas
 *     fuera, PERO CONSERVANDO las palabras vacías ("que", "es", "un"...).
 *     SearchIntentDetector la necesita así porque sus patrones buscan
 *     frases completas como "que es" o "en que ley" — si esas palabras
 *     se quitaran aquí, la intención de definición nunca se detectaría.
 *
 *   - 'palabras': la lista de palabras SIN las vacías, para todo lo que
 *     necesite comparar por concepto (LegalDictionaryService) o construir
 *     una consulta FULLTEXT sin ruido.
 *
 * Ejemplo:
 *   "¿Qué es un servicio?"
 *     -> consulta_normalizada: "que es un servicio"
 *     -> palabras: ['servicio']
 */
class SearchQueryNormalizer
{
    /**
     * Palabras que no aportan significado para FULLTEXT ni para comparar
     * contra el diccionario de conceptos. Se eliminan SOLO de la lista de
     * 'palabras', nunca de 'consulta_normalizada' (ver docblock de clase).
     */
    private const PALABRAS_VACIAS = [
        // ── Artículos, preposiciones y conjunciones ──
        'que', 'es', 'un', 'una', 'unos', 'unas', 'el', 'la', 'los', 'las',
        'de', 'del', 'al', 'para', 'con', 'por', 'en', 'y', 'o', 'a',
        'se', 'su', 'sus', 'lo', 'como', 'cual', 'cuales', 'donde',
        'cuando', 'quien', 'quienes', 'este', 'esta', 'estos', 'estas',

        // ── PALABRAS DE PREGUNTA ──
        //
        // Estas faltaban, y eran la mitad del problema.
        //
        // El normalizador se diseñó para reconocer CONCEPTOS ("qué es un servicio"), no para
        // digerir PREGUNTAS COMPLETAS ("cuánto paga un semifijo por la basura"). Y un ciudadano
        // no escribe conceptos: escribe preguntas.
        //
        // El resultado era este: la consulta full-text exige que TODAS las palabras aparezcan en
        // el artículo (' & ' en tsquery). Y ningún artículo de la Ley de Hacienda contiene la
        // palabra "cuanto" ni la palabra "paga". La ley dice "cuota", "cubrirán", "el pago del
        // derecho será".
        //
        // Así que la búsqueda devolvía CERO resultados — no porque la ley no lo dijera, sino
        // porque el ciudadano no había adivinado las palabras exactas de la ley. Y si las
        // hubiera adivinado, no habría necesitado preguntar.
        //
        // Estas palabras describen la FORMA de la pregunta, no su CONTENIDO. Quitarlas no pierde
        // información: la deja al descubierto.
        //
        //     "cuanto paga un semifijo en basura"  →  ['semifijo', 'basura']
        //
        // OJO: se quitan solo de la lista 'palabras' (la que alimenta al full-text). La
        // 'consulta_normalizada' las conserva ENTERAS, porque el detector de intención las
        // necesita: es justamente por el "cuánto" por lo que sabe que preguntan un COSTO.
        'cuanto', 'cuanta', 'cuantos', 'cuantas', 'cuánto', 'cuánta', 'cuántos', 'cuántas',
        'cuesta', 'cuestan', 'cueste',
        'paga', 'pagan', 'pago', 'pagar', 'pagas', 'pagaria', 'pagaría',
        'cobra', 'cobran', 'cobro', 'cobrar',
        'necesito', 'necesita', 'necesitan', 'requiere', 'requieren',
        'debo', 'debe', 'deben', 'tengo', 'tiene', 'tienen', 'hay',
        'puedo', 'puede', 'pueden', 'sirve', 'sirven',
        'saber', 'quiero', 'quisiera', 'busco', 'buscar',
        'dime', 'dice', 'sobre', 'acerca', 'respecto',
        'me', 'mi', 'mis', 'te', 'tu', 'tus', 'nos', 'les', 'le',
        'soy', 'eres', 'somos', 'son', 'estoy', 'esta', 'estan', 'están',
        'si', 'no', 'mas', 'más', 'muy', 'todo', 'toda', 'todos', 'todas',
    ];

    /**
     * Normaliza una consulta completa.
     *
     * @return array{consulta_normalizada: string, palabras: array<string>}
     */
    public function normalizar(string $consultaOriginal): array
    {
        $texto = TextoNormalizador::normalizar(trim($consultaOriginal));

        // Quitar signos de interrogación, puntuación y cualquier carácter
        // que no sea letra, número o espacio.
        $texto = preg_replace('/[^\p{L}\p{N}\s]/u', ' ', $texto);

        // Colapsar espacios múltiples que pudo dejar el paso anterior.
        $consultaNormalizada = preg_replace('/\s+/', ' ', trim($texto));

        $todasLasPalabras = $consultaNormalizada === '' ? [] : explode(' ', $consultaNormalizada);

        $palabrasRelevantes = array_values(array_filter(
            $todasLasPalabras,
            fn ($palabra) => !in_array($palabra, self::PALABRAS_VACIAS, true) && $palabra !== ''
        ));

        return [
            'consulta_normalizada' => $consultaNormalizada, // CON palabras vacías, para el detector de intención
            'palabras'             => $palabrasRelevantes,   // SIN palabras vacías, para diccionario y FULLTEXT
        ];
    }
}
